package tryandcatch;

public class TryanCatch {
    public static void main(String[] args)
    {
 
    		String s=null;
    		
    	
        try
        {
        
        	System.out.println(s.length());
        }
        catch(NullPointerException e)
        {
        	System.out.println(e);
        }
        finally
        {
        	System.out.println("String does not contain any characters,it does not have any length");
        }
    }
    }

