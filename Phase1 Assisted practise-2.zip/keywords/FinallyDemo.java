package keywords;

public class FinallyDemo {
	
	public static void main(String[] args)
	{
		int a=45,b=0,r=0;
		try
		{
			r=a/b;
		}
		catch(ArithmeticException Ex)
		{
			System.out.println("\n\tError:"+Ex.getMessage());
		}
		finally
		{
			System.out.println("\n\tThe result is:"+r);
		}
	}

}
