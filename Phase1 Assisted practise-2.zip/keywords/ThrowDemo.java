package keywords;

public class ThrowDemo {

	public static void main(String[] args)
	{
		
			int a=45,b=0,r;
			try
			{
				if(b==0)
				{
					throw(new ArithmeticException("can't divide by zero."));
			}
				else
				{
					r=a/b;
				System.out.println("\n\tThe result is:"+r);
		}
	}
			catch(ArithmeticException Ex)
			{
				System.out.println("\n\tError:"+Ex.getMessage());
			}
}
}
