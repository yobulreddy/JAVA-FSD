package oopspillars;

public class Encapsulation{

	private String Name;
	private int roll;
	private int Age;
	public int getAge()
	{
		return Age;
	}
	public String getName()
	{
		return Name;
	}
	public int getRoll()
	{
		return roll;
	}
	public void setName(String newName)
	{
		Name=newName;
	}
	public void setAge(int newAge)
	{
		Age=newAge;
	}
	public void setRoll(int newRoll)
	{
		roll=newRoll;
	}
}

