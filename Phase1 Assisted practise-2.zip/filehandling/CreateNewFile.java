package filehandling;

import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.List;


public class CreateNewFile {
 
	public static void main(String[] args)throws IOException
	{
		createFileUsingFileClass();
		createFileUsingOutputStreamClass();
		createFile_NIO();
	}
	private static void createFileUsingFileClass() throws IOException
	{
		File file=new File("C:\\Temp\\test1.txt");
		
		//create the file
		if(file.createNewFile())
		{
			System.out.println("File is Created!");
		}
		else
		{
			System.out.println("File already exists");
		}
		
		//write content
		FileWriter writer=new FileWriter(file);
		writer.write("Test data");
		writer.close();
}
	private static void createFileUsingOutputStreamClass() throws IOException
	{
		String data ="Test data";
		FileOutputStream out=new FileOutputStream("C:\\Temp\\test2.txt");
		out.write(data.getBytes());
		
		out.close();
	}
	private static void createFile_NIO() throws IOException
	{
		String data ="Test data";
		Files.write(Paths.get("C:\\Temp\\test3.txt"),data.getBytes());
		List<String>lines=Arrays.asList("1st line","2nd line");
				Files.write(Paths.get("file6.txt"),
						lines,
						StandardCharsets.UTF_8,
						StandardOpenOption.CREATE,
						StandardOpenOption.APPEND);								
	}
	}
	
