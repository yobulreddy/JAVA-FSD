package diamondproblem;

	interface Test1
	{
		default void show()
		{
			System.out.println("Default first");
		}
	}
		interface Test2
		{
			default void show()
			{
			System.out.println("Default second");	
			}
			
		}
		

	public class Diamond implements Test1,Test2
	{

		@Override
		public void show() 
			{
				Test1.super.show();	
				Test2.super.show();
				}
		public static void main(String[] args)
		{
			Diamond db=new Diamond();
			 db.show();
		}
		
}

