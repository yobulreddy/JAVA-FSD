package exceptionhandling;

public class Example1 {
	public static void main(String[] args)
	{
		try
		{
			System.out.println("starting of try block");
         throw new MyException("This is My Error Message");
	}
		catch(MyException exp)
		{
			System.out.println("catch block");
			System.out.println(exp);
		}
}

}
