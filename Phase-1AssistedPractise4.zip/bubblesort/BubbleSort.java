package bubblesort;

public class BubbleSort {
	public static void bubble(int[] arr)
	{
		for(int i=0;i<arr.length;i++)
		{
			for(int j=1;j<arr.length-i;j++)
			{
				if(arr[j-1]>arr[j])
				{
					int temp=arr[j-1];
					arr[j-1]=arr[j];
					arr[j]=temp;
				}
			}
		}
	}
	public static void main(String[] args)
	{
		int arr[]= {3,45,24,55,345,67,89,8};
		System.out.println("Before sorting");
		for(int k:arr)
		{
			System.out.print(k+" ");
		}
		bubble(arr);
		System.out.println("\nAfter sorting");
		for(int x:arr)
		{
			System.out.print(+x+" ");
		}
	}
}
