package linearsearch;
import java.util.Scanner;
public class LinearSearch {
	public static void search(int[] arr,int search_element)
	{   
		int flag=0;
		for(int i=0;i<arr.length;i++)
		{
			if(search_element==arr[i])
			{  
				System.out.println("the search element "+arr[i]+" is found in the array at "+i+"th index");
				flag++;
				break;
			}
		}
		if(flag==0)
		{
			System.out.println("the element we are searched was not found in the array");
		}
	}
	
	public static void main(String[] args)
	{
		Scanner sc=new Scanner(System.in);
		//creating an integer array
		int arr[]= {23,45,67,89,01,23,4,5,67,9};
		System.out.println("enter the element to search");
		//entering the element to search
		int search_element=sc.nextInt();
		search(arr,search_element);
	}

}
