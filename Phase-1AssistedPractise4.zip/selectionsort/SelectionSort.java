package selectionsort;

public class SelectionSort {

	public static void main(String[] args)
	{
		//create an Array
		int x[]= {23,45,6,7,8,1,9,0};
		
	//before sorting
	System.out.println("Before sorting");
	for(int n:x)
	{
		System.out.print(n+" ");
	}
	
	//sort the elements
	for(int i=0;i<x.length;i++)
	{
		int min=i;
		for(int j=i+1;j<x.length;j++)
		{
			if(x[j]<x[min])
				min=j;
		}
		int temp=x[i];
		x[i]=x[min];
		x[min]=temp;
	}
	//elements after sorting
	System.out.println("\nAfter sorting");
	for(int k:x)
	{
		System.out.print(k+" ");
	}
}
}