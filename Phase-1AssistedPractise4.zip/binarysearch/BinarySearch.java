package binarysearch;
import java.util.Scanner;
public class BinarySearch {
	 
	    public static int binarySearch(int arr[], int first, int last, int searchelement){  
	        if (last>=first){  
	            int mid = first + (last - first)/2;  
	            if (arr[mid] == searchelement){  
	            return mid;  
	            }  
	            if (arr[mid] > searchelement){  
	            return binarySearch(arr, first, mid-1, searchelement);//search in left subarray  
	            }else{  
	            return binarySearch(arr, mid+1, last, searchelement);//search in right subarray  
	            }  
	        }  
	        return -1;  
	    }  
	    public static void main(String args[]){ 
	    	Scanner sc=new Scanner(System.in);
	        int arr[] = {10,20,30,40,50};  
	        System.out.println("enter the element to search");
	        int searchelement = sc.nextInt();
	        int last=arr.length-1;  
	        int result = binarySearch(arr,0,last,searchelement);  
	        if (result == -1)  
	            System.out.println("Element is not found!");  
	        else  
	            System.out.println("Element is found at index: "+result);  
	    }  
	}
