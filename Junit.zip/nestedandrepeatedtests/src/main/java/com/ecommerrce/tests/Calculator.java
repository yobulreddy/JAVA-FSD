package com.ecommerrce.tests;
public class Calculator
{
 public int adding(int a, int b) {
 return a + b;
 }
}