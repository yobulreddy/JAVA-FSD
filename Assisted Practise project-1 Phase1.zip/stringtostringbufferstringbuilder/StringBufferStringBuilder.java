package stringtostringbufferstringbuilder;

public class StringBufferStringBuilder {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// creating a string with new keyword
		String s1=new String("hi am obul reddy yarraguntla");
		//creating string without new keyword
		String s2="climate in Bangalore was very cool";
		System.out.println("methods of string");
		
		//comparison of two strings
		System.out.println(s1.compareTo(s2));
		
		String s3="";
		
		//isEmpty
		System.out.println(s3.isEmpty());
				
		//replace string
		System.out.println(s2.replace("Bangalore", "hyderabad"));
		
		//substring
		System.out.println(s1.substring(6));
		
		//equals
		System.out.println(s1.equals(s2));
		
		//Creating StringBuffer
		StringBuffer sb=new StringBuffer("hello world");
		//append method
		sb.append("how are you");
		System.out.println(sb);
		//insert method
		System.out.println(sb.insert(0, 'w'));
		
		//creating StringBuilder

		StringBuilder sb1=new StringBuilder("welcome to java");
		//append method
		System.out.println(sb1.append("learning"));
		
		//conversion of String to StringBuffer
		
		String s6="hello";
		StringBuffer sb2=new StringBuffer(s6);
		sb2.reverse();
		System.out.println("string to stringbuffer");
		System.out.println(sb2);
		
		
		//conversion of String to Stringbuilder
		
		StringBuilder sb3=new StringBuilder(s6);
		sb3.append("world");
		System.out.println("String to StringBuilder");
		System.out.println(sb3);
		
		
		
		
	}

}
