package constructors;

public class Emp {
	String name;
	int id;
	void display() {
		System.out.println(id+" "+name);
	}
	Emp(String n, int i)
	{
		name=n;
		id=i;
		
	}

}
