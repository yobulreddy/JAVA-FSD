package constructors;

public class DefaultConstructor {

	public static void main(String[] args)
	{
		ConstStudent s1=new ConstStudent();
		ConstStudent s2=new ConstStudent();
		s1.display();
		s2.display();
	}
}
