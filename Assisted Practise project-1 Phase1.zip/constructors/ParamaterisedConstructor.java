package constructors;

public class ParamaterisedConstructor {
 
	public static void main(String[] args)
	{
		Emp e1=new Emp("shyam",43524);
		Emp e2=new Emp("ram",75865);
		e1.display();
		e2.display();
}
}
