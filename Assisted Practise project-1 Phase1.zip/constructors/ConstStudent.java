package constructors;

public class ConstStudent {
	
		String name;
		int id;
		float percentage;
		
		void display(){
			System.out.println("display student details with marks"
					+name+" "+percentage);
		}

}
