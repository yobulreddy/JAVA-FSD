package maps;

import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.TreeMap;

public class Maps {
	
	public static void main(String[] args)
	{
		
		//HashMap
		HashMap<Integer,String> hm=new HashMap<Integer,String>();
		
		hm.put(1, "Tim");
		hm.put(2, "Mary");
		hm.put(3, "catie");
		System.out.println("\n The elements of HashMap are");
		for(Map.Entry m:hm.entrySet()) {
			System.out.println(m.getKey()+""+m.getValue());
			
		}
		//Hashtable
Hashtable<Integer,String> ht=new Hashtable<Integer,String>();
		
		ht.put(4, "Ales");
		ht.put(5, "Rosy");
		ht.put(6, "Jack");
		System.out.println("\n The elements of HashMap are");
		for(Map.Entry m:ht.entrySet()) {
			System.out.println(m.getKey()+""+m.getValue());
		}
		//TreeMap
TreeMap<Integer,String> tm=new TreeMap<Integer,String>();
		
		tm.put(7, "Annie");
		tm.put(8, "carlotte");
		tm.put(9, "catie");
		System.out.println("\n The elements of HashMap are");
		for(Map.Entry m:tm.entrySet()) {
			System.out.println(m.getKey()+""+m.getValue());
		}
		}


	}

