package accessmodifiers2;

public class ProtectedaccessSpecifiers {

	protected void display()
	{
		System.out.println("This is protected access specifier");
	}
}
