package accessmodifiers2;

public class PubaccessSpecifiers {
 
	public void display()
	{
		System.out.println("This is public Access specifiers");
	}
}
