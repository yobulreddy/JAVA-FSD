package methods;


public class DemoMethod {
	
	public static void sum(int a,int b)
	{
		int sum=a+b;
		System.out.println("ths sum of "+a+" and "+b+" is "+sum);
	}
	public static void main(String[] args)
	{
		DemoMethod d = new DemoMethod();
		d.sum(23,47);
	}

}
