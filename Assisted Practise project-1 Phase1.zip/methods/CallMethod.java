package methods;


public class CallMethod {
	
	       int val=150;  
		  int operation(int val)
		  {
			  val=val*10/100;
			  return val;
		  }
		  
		  public static void main(String[] args)
		  {
			  CallMethod cm=new CallMethod();
			  System.out.println("before operation value od data is"+cm.val);
			  System.out.println("after operation value of data is"+cm.operation(100));
			  }
	}



