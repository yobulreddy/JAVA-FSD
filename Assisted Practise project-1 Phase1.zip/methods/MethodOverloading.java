package methods;

public class MethodOverloading {
	public static void product(int x,int y)
	{
		int prod=x*y;
		System.out.println("the product of "+x+" and "+y+" is "+prod);
	}
	public static void product(int x,int y,int z)
	{
		int prod=x*y*z;
		System.out.println("the product of "+x+","+y+"and"+z+"is"+prod);
	}
	public static void main(String[] args) {
		
		MethodOverloading m = new MethodOverloading();
		   m.product(12,34,57);
		   m.product(56,78);

	}

}
