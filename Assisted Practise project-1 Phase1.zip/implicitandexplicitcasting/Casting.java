package implicitandexplicitcasting;

public class Casting {
	public static void main(String[] args)
	{   //implicit conversion
		System.out.println("implicit type casting");
		
		char a='A';
		System.out.println("the value of a is "+a);
		int b=a;
		System.out.println("the value of b is "+b);
		float c=a;
		System.out.println("the value of c is "+c);
		double d=a;
		System.out.println("the value of d is "+d);
		
		//explicit type casting
		System.out.println("explicit type casting");
		double e=124.0;
		int f=(int)e;
		System.out.println("the value of f is "+f);
		float g=(float)e;
		System.out.println("the value of g is "+g);
		char h=(char)e;
		System.out.println("the value of h is "+h);
		
		
	}

}
