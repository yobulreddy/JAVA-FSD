package arrays;

public class Arrays {
	
	public static void main(String[] args)
	//single dimensional array
	{
	
	int a[]= {10,20,30,40,50};
	
	for(int i=0;i<a.length;i++)
	{
		System.out.println("the elements in an array a is"+a[i]);
		
	}
	
	int b[][]= {{2,3,4,5,6},{45,76,89}};
	System.out.println("the length of second row in b is"+b[1].length);

}
}
