package innerclass;



public class Innerclass {
	public static void main(String[]args)
	 {
		 AnonymousInnerClass a=new AnonymousInnerClass() {
			 
			 public void display()
			 {
				 System.out.println("Anonymous inner class");
				 
			 }
		 };
		 
		 a.display();
}
}
