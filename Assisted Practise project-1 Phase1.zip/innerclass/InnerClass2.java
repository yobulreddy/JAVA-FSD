package innerclass;



public class InnerClass2 {
	
	private String s="Inner class";
	void display()
	{
		class Inner
		{
			void msg()
			{
				System.out.println(s);
			}
		}
		
		Inner i=new Inner();
		i.msg();
	}
	
	public static void main(String[] args)
	{
	InnerClass2 obj= new InnerClass2();
	obj.display();
	}


}
