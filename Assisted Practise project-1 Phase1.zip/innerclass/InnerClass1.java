package innerclass;


public class InnerClass1 {
private String msg="welcome to java";
	
	public class Inner{
		public void hello()
		{
			System.out.println("let us learn java programming language");
		}
	}
		public static void main(String[] args)
		{
			InnerClass1 obj=new InnerClass1();
			InnerClass1.Inner i=obj.new Inner();
			i.hello();
		}
}
