package innerclass;

abstract class AnonymousInnerClass {
	abstract void display();


}
