package accessmodifiers;

public class PriaccessSpecifier {
	private void display()
	{
		System.out.println("you are using private access specifier");
	}
}
