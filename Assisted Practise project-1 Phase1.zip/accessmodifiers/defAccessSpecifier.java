package accessmodifiers;

public class defAccessSpecifier {
  
	void display()
	{
		System.out.println("you are using default access specifier");
	}
}
