package accessmodifiers3;

import accessmodifiers2.*;
public class AccessSpecifiers3 extends ProtectedaccessSpecifiers{
	
	public static void main(String[] args)
	{
		AccessSpecifiers3 obj=new AccessSpecifiers3();
		obj.display();
	}

}
