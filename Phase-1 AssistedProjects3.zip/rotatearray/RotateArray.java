package rotatearray;

public class RotateArray{
	public static void main(String[] args)
	{
		//initialize array
		int a[]=new int[] {1,2,3,4,5,6,7};
	
	//determine the number of times an array should be rotated
	int n=5;

    //Display the original array
  System.out.println("original array");
  for(int i=0;i<a.length;i++)
  {
	  System.out.print(a[i]+" ");
  }
  
  for(int i=0;i<n;i++)
  {
	  int j,last;
	  last=a[a.length-1];
  
  for(j=a.length-1;j>0;j--)
  {
	  a[j]=a[j-1];
  }
   a[0]=last;
  }
  System.out.println("\nArray after right rotation");
  for(int i=0;i<a.length;i++)
  {
	  System.out.print(a[i]+" ");
  }
}
}